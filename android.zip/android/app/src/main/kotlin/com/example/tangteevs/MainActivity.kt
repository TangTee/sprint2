package com.example.tangteevs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
